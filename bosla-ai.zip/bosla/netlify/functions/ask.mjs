import { KB } from './kb.mjs';

const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

const SYSTEM = `أنت «مساعد بوصلة مستقبلك»، تساعد طالب سعودي قبل اختيار تخصصه الجامعي.
القواعد:
- رد باللهجة السعودية البسيطة، قصير وواضح (٣ إلى ٦ أسطر).
- اعتمد فقط على المعلومات المرفقة: نتيجة الطالب، ومعلومات التخصصات، ومقابلات الممارسين.
- إذا نقلت كلام ممارس، اذكر اسمه ودوره، مثل: «رباب (سيستم أدمن) تقول...».
- إذا ما لقيت الجواب في المعلومات المرفقة، قل بصراحة إنك ما عندك معلومة عنه، ولا تخترع أرقام أو رواتب أو أسماء جامعات.
- لا تعطي حكم نهائي على مستقبل الطالب، الميول مؤشر مو قدر.
- لا تطلب من الطالب أي معلومات شخصية.
- إذا السؤال خارج اختيار التخصص، رجّعه بلطف للموضوع.`;

const clip = (s, n) => String(s ?? '').slice(0, n);

export default async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const key = process.env.GEMINI_API_KEY;
  if (!key) return Response.json({ error: 'no_key' }, { status: 500 });

  let b;
  try { b = await req.json(); } catch { return Response.json({ error: 'bad_json' }, { status: 400 }); }
  const q = clip(b.q, 500).trim();
  if (!q) return Response.json({ error: 'empty' }, { status: 400 });

  const majors = Array.isArray(b.majors) ? b.majors.slice(0, 8) : [];
  const ids = majors.map((m) => m && m.id).filter(Boolean);
  const interviews = ids.flatMap((id) => (KB[id] || []).map((p) => ({ major: id, ...p })));

  const context = {
    student: { sex: b.sex === 'f' ? 'أنثى' : 'ذكر', topInterests: clip(b.top, 200) },
    majors,
    practitionerInterviews: interviews,
  };
  const history = (Array.isArray(b.history) ? b.history.slice(-6) : [])
    .filter((h) => h && (h.r === 'user' || h.r === 'model'))
    .map((h) => ({ role: h.r, parts: [{ text: clip(h.t, 800) }] }));

  const body = {
    systemInstruction: { parts: [{ text: SYSTEM + '\n\nالمعلومات المرفقة (JSON):\n' + clip(JSON.stringify(context), 30000) }] },
    contents: [...history, { role: 'user', parts: [{ text: q }] }],
    generationConfig: { temperature: 0.3, maxOutputTokens: 600 },
  };

  try {
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify(body),
    });
    if (!r.ok) return Response.json({ error: 'upstream', status: r.status }, { status: 502 });
    const j = await r.json();
    const text = (j.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('').trim();
    if (!text) return Response.json({ error: 'empty_answer' }, { status: 502 });
    return Response.json({ text });
  } catch (e) {
    return Response.json({ error: 'network' }, { status: 502 });
  }
};

export const config = { path: '/api/ask' };
